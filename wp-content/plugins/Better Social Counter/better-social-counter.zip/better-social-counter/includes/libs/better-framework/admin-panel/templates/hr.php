<div class="bf-section-container bf-clearfix" <?php echo bf_show_on_attributes( $options ); ?>>

	<div class="bf-section-hr bf-clearfix">
		<?php echo $input; // escaped before in generating ?>
	</div>
</div>