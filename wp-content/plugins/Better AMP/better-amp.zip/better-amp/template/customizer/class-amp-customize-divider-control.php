<?php

class AMP_Customize_Divider_Control extends WP_Customize_Control {

	protected function render_content() {
		?>
		<hr>
		<?php
	}

}
