# better-amp
Full Google AMP support for WordPress with custom themes and customizations - Demo: http://demo.betterstudio.com/publisher/amp-demo/
